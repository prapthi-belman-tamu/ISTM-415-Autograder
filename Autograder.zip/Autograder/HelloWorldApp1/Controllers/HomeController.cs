using Microsoft.AspNetCore.Mvc;

namespace HelloWorldApp.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet("/")]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost("/echo")]
        public IActionResult Echo([FromForm] string message)
        {
            return Content(message ?? "");
        }

        [HttpGet("/about")]
        public IActionResult About() => View();

        [HttpGet("/contact")]
        public IActionResult Contact() => View();
    }
}

﻿using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

namespace Grader.Tests1
{
    public class HelloWorldUiTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly HttpClient _client;

        public HelloWorldUiTests(WebApplicationFactory<Program> factory)
        {
            _client = factory.CreateClient(new WebApplicationFactoryClientOptions
            {
                AllowAutoRedirect = false
            });
        }

        [Fact(DisplayName = "Home page loads with 200 OK")]
        public async Task HomePage_Loads()
        {
            var resp = await _client.GetAsync("/");
            Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
        }

        [Fact(DisplayName = "Home page contains <h1>Hello, ISTM 415!>")]
        public async Task HomePage_HasHelloHeader()
        {
            var resp = await _client.GetAsync("/");
            var html = await resp.Content.ReadAsStringAsync();
            Assert.Contains("Hello, ISTM 415!", html);
        }

        [Fact(DisplayName = "Echo form POST returns the same message")]
        public async Task EchoForm_ReturnsPostedMessage()
        {
            // Arrange: mimic typing into the input box
            var formData = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string,string>("message", "test-message")
            });

            // Act: submit form to /echo
            var resp = await _client.PostAsync("/echo", formData);

            // Assert
            Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
            var body = await resp.Content.ReadAsStringAsync();
            Assert.Equal("test-message", body.Trim());
        }

        [Fact(DisplayName = "Form has a submit button")]
        public async Task Form_HasSubmitButton()
        {
            var resp = await _client.GetAsync("/");
            var html = await resp.Content.ReadAsStringAsync();
            Assert.Contains("<button", html);  // crude check — ensures a button exists
        }
    }
}

param(
  # Default to the TRX that lives next to this script (Grader.Tests1\TestResults\latest.trx)
  [string]$TrxPath = "$PSScriptRoot\TestResults\latest.trx"
)

# ---- weights (25 pts each) ----
$weights = @{
  "Home page loads with 200 OK"                = 25
  "Home page contains <h1>Hello, ISTM 415!>"   = 25
  "Echo form POST returns the same message"    = 25
  "Form has a submit button"                   = 25
}

# ---- read trx ----
if (-not (Test-Path $TrxPath)) {
  Write-Error "TRX not found at: $TrxPath. Run 'dotnet test -l ""trx;LogFileName=latest.trx""' first."
  exit 1
}
[xml]$trx = Get-Content $TrxPath
$unit = $trx.TestRun.Results.UnitTestResult

# ---- compute ----
$passed = @{}
foreach ($r in $unit) { $passed[$r.testName] = ($r.outcome -eq 'Passed') }

$score = 0
$passedNames = @()
$failedNames = @()

foreach ($k in $weights.Keys) {
  if ($passed.ContainsKey($k) -and $passed[$k]) {
    $score += $weights[$k]
    $passedNames += $k
  } else {
    $failedNames += $k
  }
}

# ---- outputs ----
$total = ($weights.Values | Measure-Object -Sum).Sum
$now = Get-Date
$stamp = $now.ToString('yyyy-MM-dd_HH-mm-ss')

$reportObj = [PSCustomObject]@{
  Total  = $total
  Score  = $score
  Passed = ($passedNames -join ', ')
  Failed = ($failedNames -join ', ')
  Timestamp = $now
}

# pretty console summary
Write-Host ""
if ($failedNames.Count -eq 0) {
  Write-Host ("Score: {0}/{1}" -f $score, $total) -ForegroundColor Green
} else {
  Write-Host ("Score: {0}/{1}" -f $score, $total) -ForegroundColor Yellow
}
Write-Host ("Passed: {0}" -f ($passedNames -join "; "))
if ($failedNames.Count -gt 0) {
  Write-Host ("Failed: {0}" -f ($failedNames -join "; ")) -ForegroundColor Red
}
Write-Host ""

# save artifacts
$reportsDir = Join-Path $PSScriptRoot "Reports"
New-Item -ItemType Directory -Force -Path $reportsDir | Out-Null

$jsonPath = Join-Path $reportsDir "report_$stamp.json"
$csvPath  = Join-Path $reportsDir "report_$stamp.csv"
$txtPath  = Join-Path $reportsDir "report_$stamp.txt"

$reportObj | ConvertTo-Json -Depth 3 | Out-File -Encoding utf8 $jsonPath
$reportObj | Export-Csv -NoTypeInformation -Path $csvPath
@(
  "Score: $score / $total",
  "Passed: $($reportObj.Passed)",
  "Failed: $($reportObj.Failed)",
  "When:   $($reportObj.Timestamp)"
) | Out-File -Encoding utf8 $txtPath

# exit code (useful for CI)
if ($score -lt $total) { exit 2 } else { exit 0 }

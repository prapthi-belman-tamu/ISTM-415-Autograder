﻿using System.Net;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

namespace Grader.Tests1   // <-- match your test project name
{
    public class HomeControllerContentTests
        : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly HttpClient _client;

        public HomeControllerContentTests(WebApplicationFactory<Program> factory)
        {
            _client = factory.CreateClient(new WebApplicationFactoryClientOptions
            {
                AllowAutoRedirect = false
            });
        }

        [Fact(DisplayName = "Home / renders Hello message")]
        public async Task Index_ReturnsHelloWorldMessage()
        {
            var resp = await _client.GetAsync("/");
            Assert.Equal(HttpStatusCode.OK, resp.StatusCode);

            var html = await resp.Content.ReadAsStringAsync();
            Assert.Contains("Hello", html, StringComparison.OrdinalIgnoreCase);
        }
    }
}

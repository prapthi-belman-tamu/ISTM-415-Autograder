Param(
  [string]$TestsProject = "Grader.Tests1",
  [string]$LogFileName = "latest.trx"
)

$ErrorActionPreference = 'Stop'
$root     = $PSScriptRoot
$testsDir = Join-Path $root $TestsProject

if (-not (Test-Path $testsDir)) {
  throw "Could not find tests project folder at '$testsDir'."
}

Push-Location $testsDir
try {
  # 1) Run tests and write TRX
  dotnet test -l "trx;LogFileName=$LogFileName" | Out-Null

  # 2) Run the scorer (assumes Score.ps1 is in this folder)
  $json = & "$testsDir\Score.ps1"
}
finally {
  Pop-Location
}

# 3) Print the JSON so the autograder can read it
$json

# 4) Exit with 0 on full score, 1 otherwise
try {
  $o = $json | ConvertFrom-Json
  if ($o.Score -lt $o.Total) { exit 1 } else { exit 0 }
} catch {
  # If JSON can't be parsed, treat as failure
  exit 1
}
